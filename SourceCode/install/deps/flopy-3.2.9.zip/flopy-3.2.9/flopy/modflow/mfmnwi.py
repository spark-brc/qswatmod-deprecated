import sys

from ..utils.flopy_io import line_parse, pop_item

from ..pakbase import Package
from ..utils import check


class ModflowMnwi(Package):
    """
    'Multi-Node Well Information Package Class'

    Parameters
    ----------
    model : model object
        The model object (of type :class:`flopy.modflow.mf.Modflow`) to which
        this package will be added.
    wel1flag : integer
        Flag indicating output to be written for each MNW node at the end of each stress period
    qsumflag :integer
        Flag indicating output to be written for each multi-node well
    byndflag :integer
        Flag indicating output to be written for each MNW node
    mnwobs :integer
        Number of multi-node wells for which detailed flow, head, and solute data re to be saved
    wellid_unit_qndflag_qhbflag_concflag : list of lists
        Containing wells and related information to be output (length : [MNWOBS][4or5])
    extension : string
        Filename extension (default is 'mnwi')
    unitnumber : int
        File unit number (default is None).
    filenames : str or list of str
        Filenames to use for the package and the output files. If
        filenames=None the package name will be created using the model name
        and package extension and the output names will be created using
        the model name and output extensions. Default is None.

    Attributes
    ----------

    Methods
    -------

    See Also
    --------

    Notes
    -----

    Examples
    --------

    >>> import flopy
    >>> ml = flopy.modflow.Modflow()
    >>> ghb = flopy.modflow.ModflowMnwi(ml, ...)

    """

    def __init__(self, model, wel1flag=None, qsumflag=None, byndflag=None,
                 mnwobs=1, wellid_unit_qndflag_qhbflag_concflag=None,
                 extension='mnwi', unitnumber=None, filenames=None):
        # set default unit number of one is not specified
        if unitnumber is None:
            unitnumber = ModflowMnwi.defaultunit()

        # determine the number of unique unit numbers in dataset 3
        unique_units = []
        if wellid_unit_qndflag_qhbflag_concflag is not None:
            for t in wellid_unit_qndflag_qhbflag_concflag:
                iu = int(t[1])
                if iu not in unique_units:
                    unique_units.append(iu)

        # set filenames
        nfn = 4 + len(unique_units)
        if filenames is None:
            filenames = [None for x in range(nfn)]
        elif isinstance(filenames, str):
            filenames = [filenames] + [None for x in range(nfn)]
        elif isinstance(filenames, list):
            if len(filenames) < nfn:
                n = nfn - len(filenames) + 1
                filenames = filenames + [None for x in range(n)]

        # update external file information with unit_pc output, if necessary
        if wel1flag is not None:
            fname = filenames[1]
            model.add_output_file(wel1flag, fname=fname,
                                  extension='wel1',
                                  binflag=False,
                                  package=ModflowMnwi.ftype())
        else:
            wel1flag = 0

        # update external file information with unit_ts output, if necessary
        if qsumflag is not None:
            fname = filenames[2]
            model.add_output_file(qsumflag, fname=fname,
                                  extension='qsum',
                                  binflag=False,
                                  package=ModflowMnwi.ftype())
        else:
            qsumflag = 0

        # update external file information with ipunit output, if necessary
        if byndflag is not None:
            fname = filenames[3]
            model.add_output_file(byndflag, fname=fname,
                                  extension='bynd',
                                  binflag=False,
                                  package=ModflowMnwi.ftype())
        else:
            byndflag = 0

        idx = 4
        for iu in unique_units:
            fname = filenames[idx]
            model.add_output_file(iu, fname=fname,
                                  extension='{:04d}.mnwobs'.format(iu),
                                  binflag=False,
                                  package=ModflowMnwi.ftype())
            idx += 1

        name = [ModflowMnwi.ftype()]
        units = [unitnumber]
        extra = ['']

        # set package name
        fname = [filenames[0]]

        # Call ancestor's init to set self.parent, extension, name and unit number
        Package.__init__(self, model, extension=extension, name=name,
                         unit_number=units, extra=extra, filenames=fname)

        self.url = 'mnwi.htm'
        self.heading = '# {} package for '.format(self.name[0]) + \
                       ' {}, '.format(model.version_types[model.version]) + \
                       'generated by Flopy.'
        self.wel1flag = wel1flag  # -integer flag indicating output to be written for each MNW node at the end of each stress period
        self.qsumflag = qsumflag  # -integer flag indicating output to be written for each multi-node well
        self.byndflag = byndflag  # -integer flag indicating output to be written for each MNW node
        self.mnwobs = mnwobs  # -number of multi-node wells for which detailed flow, head, and solute data re to be saved
        self.wellid_unit_qndflag_qhbflag_concflag = wellid_unit_qndflag_qhbflag_concflag  # -list of lists containing wells and related information to be output (length = [MNWOBS][4or5])

        # -input format checks:
        assert self.wel1flag >= 0, 'WEL1flag must be greater than or equal to zero.'
        assert self.qsumflag >= 0, 'QSUMflag must be greater than or equal to zero.'
        assert self.byndflag >= 0, 'BYNDflag must be greater than or equal to zero.'

        if len(self.wellid_unit_qndflag_qhbflag_concflag) != self.mnwobs:
            print('WARNING: number of listed well ids to be ' +
                  'monitored does not match MNWOBS.')

        self.parent.add_package(self)

    @staticmethod
    def load(f, model, nper=None, gwt=False, nsol=1, ext_unit_dict=None):

        if model.verbose:
            sys.stdout.write('loading mnw2 package file...\n')

        structured = model.structured
        if nper is None:
            nrow, ncol, nlay, nper = model.get_nrow_ncol_nlay_nper()
            nper = 1 if nper == 0 else nper  # otherwise iterations from 0, nper won't run

        if not hasattr(f, 'read'):
            filename = f
            f = open(filename, 'r')

        # dataset 1
        line = line_parse(next(f))
        wel1flag, qsumflag, byndflag = map(int, line)
        if wel1flag > 0:
            model.add_pop_key_list(wel1flag)
        if qsumflag > 0:
            model.add_pop_key_list(qsumflag)
        if byndflag > 0:
            model.add_pop_key_list(byndflag)


        # dataset 2
        unique_units = []
        mnwobs = pop_item(line_parse(next(f)), int)
        wellid_unit_qndflag_qhbflag_concflag = []
        if mnwobs > 0:
            for i in range(mnwobs):
                # dataset 3
                line = line_parse(next(f))
                wellid = pop_item(line, str)
                unit = pop_item(line, int)
                qndflag = pop_item(line, int)
                qbhflag = pop_item(line, int)
                tmp = [wellid, unit, qndflag, qbhflag]
                if gwt and len(line) > 0:
                    tmp.append(pop_item(line, int))
                wellid_unit_qndflag_qhbflag_concflag.append(tmp)
                if unit not in unique_units:
                    unique_units.append(unit)

        for unit in unique_units:
            model.add_pop_key_list(unit)

        # determine specified unit number
        nfn = 4 + len(unique_units)
        unitnumber = None
        filenames = [None for x in range(nfn)]
        if ext_unit_dict is not None:
            unitnumber, filenames[0] = \
                model.get_ext_dict_attr(ext_unit_dict,
                                        filetype=ModflowMnwi.ftype())
            if wel1flag > 0:
                iu, filenames[1] = \
                    model.get_ext_dict_attr(ext_unit_dict, unit=wel1flag)
            if qsumflag > 0:
                iu, filenames[2] = \
                    model.get_ext_dict_attr(ext_unit_dict, unit=qsumflag)
            if byndflag > 0:
                iu, filenames[3] = \
                    model.get_ext_dict_attr(ext_unit_dict, unit=byndflag)
            idx = 4
            for unit in unique_units:
                iu, filenames[idx] = \
                    model.get_ext_dict_attr(ext_unit_dict, unit=unit)
                idx += 1


        return ModflowMnwi(model, wel1flag=wel1flag, qsumflag=qsumflag,
                           byndflag=byndflag, mnwobs=mnwobs,
                           wellid_unit_qndflag_qhbflag_concflag=wellid_unit_qndflag_qhbflag_concflag,
                           extension='mnwi', unitnumber=unitnumber,
                           filenames=filenames)

    def check(self, f=None, verbose=True, level=1):
        """
        Check mnwi package data for common errors.

        Parameters
        ----------
        f : str or file handle
            String defining file name or file handle for summary file
            of check method output. If a string is passed a file handle
            is created. If f is None, check method does not write
            results to a summary file. (default is None)
        verbose : bool
            Boolean flag used to determine if check method results are
            written to the screen
        level : int
            Check method analysis level. If level=0, summary checks are
            performed. If level=1, full checks are performed.

        Returns
        -------
        None

        Examples
        --------

        >>> import flopy
        >>> m = flopy.modflow.Modflow.load('model.nam')
        >>> m.mnwi.check()
        """
        chk = check(self, f=f, verbose=verbose, level=level)
        if "MNW2" not in self.parent.get_package_list():
            desc = '\r    MNWI package present without MNW2 package.'
            chk._add_to_summary(type='Warning', value=0,
                                desc=desc)

        chk.summarize()
        return chk

    def write_file(self):
        """
        Write the package file.

        Returns
        -------
        None

        """

        # -open file for writing
        f = open(self.fn_path, 'w')

        # header not supported
        # # -write header
        # f.write('{}\n'.format(self.heading))

        # dataset 1 - WEL1flag QSUMflag SYNDflag
        line = '{:10d}'.format(self.wel1flag)
        line += '{:10d}'.format(self.qsumflag)
        line += '{:10d}\n'.format(self.byndflag)
        f.write(line)

        # dataset 2 - MNWOBS
        f.write('{:10d}\n'.format(self.mnwobs))

        # dataset 3 -  WELLID UNIT QNDflag QBHflag {CONCflag} (Repeat MNWOBS times)
        nitems = len(self.wellid_unit_qndflag_qhbflag_concflag[0])
        for i, t in enumerate(self.wellid_unit_qndflag_qhbflag_concflag):
            wellid = t[0]
            unit = t[1]
            qndflag = t[2]
            qhbflag = t[3]
            assert qndflag >= 0, 'QNDflag must be greater than or equal to zero.'
            assert qhbflag >= 0, 'QHBflag must be greater than or equal to zero.'
            line = '{:20s} '.format(wellid)
            line += '{:5d} '.format(unit)
            line += '{:5d} '.format(qndflag)
            line += '{:5d} '.format(qhbflag)
            if nitems == 5:
                concflag = t[4]
                assert 0 <= concflag <= 3, \
                    'CONCflag must be an integer between 0 and 3.'
                assert isinstance(concflag, int), \
                    'CONCflag must be an integer between 0 and 3.'
                line += '{:5d} '.format(concflag)
            line += '\n'
            f.write(line)

        f.close()

    @staticmethod
    def ftype():
        return 'MNWI'

    @staticmethod
    def defaultunit():
        return 58
