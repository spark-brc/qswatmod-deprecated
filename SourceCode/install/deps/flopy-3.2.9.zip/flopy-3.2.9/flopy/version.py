# flopy version file automatically created using...pre-commit.py
# created on...February 19, 2018 11:59:22

major = 3
minor = 2
micro = 9
build = 0
commit = 2671

__version__ = '{:d}.{:d}.{:d}'.format(major, minor, micro)
__build__ = '{:d}.{:d}.{:d}.{:d}'.format(major, minor, micro, build)
__git_commit__ = '{:d}'.format(commit)
